# Hannul Rodriguez-Lee
# 9/20/26
# P2HW2
# Format grades, find the average, sum, max and min

"""
Pseudocode:
1. Ask the user to enter a grade for each of the six modules.
2. Store all six grades in a list.
3. Find the lowest grade in the list.
4. Find the highest grade in the list.
5. Calculate the sum of all grades.
6. Calculate the average of the grades.
7. Display the results with the required formatting.
"""


module1 = float(input("Enter grade for Module 1: "))
module2 = float(input("Enter grade for Module 2: "))
module3 = float(input("Enter grade for Module 3: "))
module4 = float(input("Enter grade for Module 4: "))
module5 = float(input("Enter grade for Module 5: "))
module6 = float(input("Enter grade for Module 6: "))


grades = [module1, module2, module3, module4, module5, module6]


min = min(grades)
max = max(grades)
sum = sum(grades)
average = sum / len(grades)


print()
print("------------Results------------")
print(f"Lowest Grade:        {min:.1f}")
print(f"Highest Grade:       {max:.1f}")
print(f"Sum of Grades:       {sum:.1f}")
print(f"Average:             {average:.2f}")
print("--------------------------------")