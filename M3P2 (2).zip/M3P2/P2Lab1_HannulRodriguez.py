# Hannul Rodriguez-Lee
# 9/16/2026
# P2Lab1
# Preform mathematical calculations and display information to users

import math

radius = float(input("What is the radius of the circle? "))
diameter = radius * 2
circumference = 2 * math.pi * radius
area = math.pi * radius ** 2

print(f"The diameter of the circle is {diameter:.1f}")

print(f"The circumference of the circle is {circumference:.2f}")

print(f"The area of the circle is {area:.3f}")