# Hannul Rodriguez-Lee
# 9/16/2026
# P2Lab2
# Use an dictionary to determine how much gas to travel for a certain amount of miles

# Create the dictionary - car names are keys and mpg are values
cars = {"Camaro":18.21, "Prius":52.36, "Model S":110, "Silverado":26}

print(cars.keys())

# Get the users choice of car
car_name = input("Enter a vehicle to see it's mgp: ",)

# Grab the mpg associated with the car_name
car_mpg = cars[car_name]

# Display car_name and car_mpg
print(f"The {car_name} gets {car_mpg} mpg.")

# Get users amount of miles that they want to drive
miles = float(input(f"How many miles will you drive the {car_name}? "))

# Calculate gallons of gas needed
gas = miles/car_mpg

print(f"{gas:.2f} gallon(s) of gas are needed to drive the {car_name} {car_mpg}.")