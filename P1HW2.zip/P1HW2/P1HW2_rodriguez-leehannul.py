# Hannul Rodriguez-Lee
# 9/9/26
# Calculate and Display expenses
# Calculating and displaying travel expenses


# Output
print("This program calculates and displays travel expenses")
print()

budget = int(input("Enter Budget: "))
destination = input("Enter your travel destination: ")
gas = int(input("How much do you think you will spend on gas? "))
home = int(input("Approximately, how much will you need for accomodation/hotel? "))
food = int(input("Lastly, how much will you need for food? "))
balance = budget - gas - home - food

# Expenses listed

print("---------Travel Expenses---------")

print("Location: ", destination, )
print("Initial Budget: ", budget, )
print()

print("Fuel: ", gas,)
print("Accomodation: ", home,)
print("Food: ", food,)
print()

print("Remaining Balance: ", balance,)
