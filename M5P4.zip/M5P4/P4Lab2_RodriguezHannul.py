# Hannul Rodriguez-Lee
# 9/28/26
# P4 LAB2
# Use a for loop to show multiplication if the input is positive

# Create a variable to control the main loop
run_again = "yes"

while run_again == "yes":
    print()
    # Logic goes here
    # Get integer from user
    user_num = int(input("Enter an integer: "))
    if user_num < 0:
        print(" No negative numbers allowed")
    else: 
        # This means integer is positive
        for multi in range(1,13):
            print(f"{user_num} * {multi} = {user_num * multi}") 
    
    print()
    run_again = input("Would you like to run the program again? ")
    
print()
print("Program has ended")
