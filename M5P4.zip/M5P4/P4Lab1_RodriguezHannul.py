# Hannul Rodriguez-Lee
# 9/28/26
# P4 Lab1
# Use a for loop and a while loop

import turtle


# Make new window to display output
window = turtle.Screen()

# Create the turtle object that draws
mundo = turtle.Turtle()

for side in range(4):
    mundo.forward(100)
    mundo.right(90)
    
    
num = 0
while num < 3:
    mundo.forward(100)
    mundo.left(120)
    num += 1 

input()

