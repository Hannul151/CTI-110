# Hannul Rodriguez
# 9/30/26
# Create SQL database


import sqlite3

# Connect to SQLite database file (creates file if it doesn't exist)
conn = sqlite3.connect("signup_hw.db")
cursor = conn.cursor()

# Drop table so script can be re-run cleanly in class
cursor.execute("DROP TABLE IF EXISTS users")

# STUDENT CODE GOES IN THIS SECTION ONLY!!!
#--------------------------------------------------------------------------------------
# STEP 1: Create users table
# TO DO: Create a table called users with fields
# user_id, first_name, last_name, email, username, password_hash, signup_date, country, age
# I have started the table for you with the primary key 'user_id'
cursor.execute("""
CREATE TABLE users (
    user_id INTEGER AUTO_INCREMENT PRIMARY KEY, first_name VARCHAR(100), last_name VARCHAR(100), email VARCHAR(50), username VARCHAR(15), password_hash VARCHAR(15), signup_date DATE, country VARCHAR(30), age INTEGER
)""")

# STEP 2: Insert sample fake users
# TO DO: Create a list called users that will store all 10 of your fake users information.
# I have started it for you

users = [('Naruto', 'Uzamaki', 'ramen@example.com', 'LoveRamen1', 'asafdffsf', '2026-06-01', 'JAPAN', 16),
         ('Luffy', 'D. Monkey', 'kingofpirates@onep.com', 'Monkey D. Luffy', 'mug1w@ra', '2014-06-05', 'BRAZIL', 18),
         ('Malcom', 'Rojas', 'rojas324@gmail.com', 'Rojas12', 'T1bleT@p', '2024-12-14', 'PUERTO RICO', 26),
         ]


#------------------------------------------------------------------------------------
# DO NOT CODE PASS HERE!!!
# STEP 3: Run the python script! Once your done creating your table and adding in the user information
# You should run the program and it will create your database called signup_hw.db.
# You can then view it in your terminal and you can upload the .db file to a database viewer thats provided on Canvas.

cursor.executemany("""
INSERT INTO users (
    first_name, last_name, email, username, password_hash,
    signup_date, country, age
) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
""", users)

conn.commit()
conn.close()

print("✅ signup_hw.db created with users table and sample data.")

print()

conn = sqlite3.connect("signup_hw.db")
cur = conn.cursor()
for row in cur.execute("SELECT * FROM users LIMIT 10"):
    print(row)
conn.close()