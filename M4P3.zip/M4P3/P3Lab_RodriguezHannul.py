# Hannul Rodriguez
# 9/21/26
# Branching
# Display money

# get users amount of money
change = float(input("Enter an amount of money: $"))

# print out users amount 
print(f"change Amount: {change}")

# Convert money to integer
change = int(change * 100)

print(f"change amount: {change}")

# How many dollars is needed

num_dollars = change // 100
change = change - (num_dollars * 100)

num_quarters = change // 25
change = change - (num_quarters * 25)

num_dimes = change // 10
change = change - (num_dimes * 10)

num_nickles = change // 5
change = change - (num_nickles * 5)

num_pennies = change 

if num_dollars > 0:
    if num_dollars == 1:
        print(f"{num_dollars} Dollar")
    else: 
        print(f"{num_dollars} Dollars")