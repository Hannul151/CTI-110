# Hannul Rodriguez
# 9/23/26
# P3HW2 
# Use Branching to determine regular and overtime pay

# Get employee name
name = input("Enter employee's name: ")

# Get number of hours worked for the week
hours = float(input("Enter number of hours worked: "))

# Get employee pay rate
pay_rate = float(input("Enter employee's pay rate: "))

# If the employee worked more than 40 hours, the have OT
if hours > 40: 
    num_overtime = hours - 40
    OT_pay = (pay_rate * 1.5) * num_overtime
    pay = 40 * pay_rate
    gross_pay = OT_pay + pay
    
else:
    num_overtime = 0
    OT_pay = 0 
    pay = hours * pay_rate
    gross_pay = OT_pay + pay
    
# Display results
print("-" * 20)
print("Employee name:", name)
print()

print(f"{'Hours Worked':<20}{'Pay Rate':20}{'OverTime Hours':<20}{'OverTime Pay':<20}{'RegHour Pay':<20}{'Gross Pay':<20} ")
print("-" * 125)
print(f"{hours:<20}${pay_rate:<20.2f}{num_overtime:<20}${OT_pay:<20.2f}${pay:<20.2f}${gross_pay:<20.2f}")