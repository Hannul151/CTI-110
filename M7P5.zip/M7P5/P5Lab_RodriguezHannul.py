# Hannul Rodriguez-Lee
# 9/30/26
# P5 Lab
# 

#Get float input from the user
change = float(input("Enter an amount of money as a float: "))

#Convert the float value into an integer
change = int(change * 100)



    
if change == 0:
    print("No Change Due")

#Calculate the amount of each coin needed
#integer division - //

num_dollars = change // 100
change = change - (num_dollars * 100)

num_quarters = change // 25
change = change - (num_quarters * 25)

num_dimes = change // 10
change = change - (num_dimes * 10)

num_nickles = change // 5
change = change - (num_nickles *5)

num_pennies = change // 1

# Define a function to print coin values
def display_coins(num_coins, name_coin):
    if num_coins >= 1:
        if num_coins == 1:
            print(f"{name_coin}")
        if num_coins > 1:
            print(f"{num_coins} {name_coin}s")
# Call the function once for each coin
display_coins(num_dollars, "Dollar")
display_coins(num_quarters, "Quarter")
display_coins(num_dimes, "Dime")
display_coins(num_nickles, "Nickle")
display_coins(num_pennies, "Penny")