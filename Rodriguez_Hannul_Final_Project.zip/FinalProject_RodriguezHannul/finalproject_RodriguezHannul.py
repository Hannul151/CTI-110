# Your Name
# Date
# Adventure Game
# A Zelda-inspired text adventure where the hero explores a forest,
# collects items, fights enemies, and defeats the Shadow Dragon.

import random
import time


def pause(seconds=0.5):
    """Pause briefly so the adventure feels more like a game."""
    time.sleep(seconds)


def show_status(player):
    """Display the player's current health and inventory."""
    hearts = "❤️" * player["hp"] + "🖤" * (player["max_hp"] - player["hp"])
    print("\n" + "=" * 42)
    print(f"Hero: {player['name']}   HP: {hearts} ({player['hp']}/{player['max_hp']})")
    print(f"Potions: {player['potions']} | Rupees: {player['rupees']} | Relics: {player['relics']}/3")
    print("=" * 42)


def heal_player(player):
    """Use a potion to restore health."""
    if player["potions"] <= 0:
        print("You have no healing potions left!")
        return

    if player["hp"] == player["max_hp"]:
        print("Your hearts are already full. Save the potion for later!")
        return

    player["potions"] -= 1
    old_hp = player["hp"]
    player["hp"] = min(player["max_hp"], player["hp"] + 3)
    print(f"You drink a potion and recover {player['hp'] - old_hp} heart(s)! ❤️")


def fight_enemy(player, enemy_name, enemy_hp, enemy_damage, boss=False):
    """Run a turn-based battle. Return True if the player survives and wins."""
    print(f"\n⚔️  A {'BOSS' if boss else 'wild enemy'} appears: {enemy_name}!")
    pause()

    while enemy_hp > 0 and player["hp"] > 0:
        show_status(player)
        print(f"{enemy_name} HP: {'💜' * enemy_hp} ({enemy_hp})")
        print("1. Attack")
        print("2. Use a potion")
        choice = input("Choose 1 or 2: ").strip()

        if choice == "2":
            heal_player(player)
            if player["hp"] <= 0:
                break
            continue
        elif choice != "1":
            print("Choose 1 to attack or 2 to use a potion.")
            continue

        damage = random.randint(player["sword_power"], player["sword_power"] + 1)
        enemy_hp -= damage
        print(f"\nYou swing your sword and deal {damage} damage!")
        pause(0.4)

        if enemy_hp > 0:
            damage_taken = random.randint(1, enemy_damage)
            player["hp"] = max(0, player["hp"] - damage_taken)
            print(f"{enemy_name} hits you for {damage_taken} damage!")
            pause(0.4)

    if player["hp"] <= 0:
        print("\n💀 You have fallen in battle. The kingdom still needs a hero...")
        return False

    print(f"\n✨ You defeated {enemy_name}!")
    if not boss:
        reward = random.randint(2, 5)
        player["rupees"] += reward
        print(f"You collect {reward} rupees.")
    return True


def explore_forest(player):
    """Explore the forest and find a relic, supplies, or an enemy."""
    print("\n🌲 You enter the Whispering Forest.")
    print("The trees rustle. A narrow path leads deeper into the woods.")
    event = random.choice(["enemy", "potion", "rupees", "relic"])

    if event == "enemy":
        won = fight_enemy(player, "Forest Goblin", random.randint(3, 5), 2)
        if not won:
            return False
    elif event == "potion":
        player["potions"] += 1
        print("🍶 You find a healing potion tucked beside an old tree.")
    elif event == "rupees":
        found = random.randint(3, 7)
        player["rupees"] += found
        print(f"💎 You find {found} rupees hidden beneath some leaves.")
    else:
        if player["relics"] < 3:
            player["relics"] += 1
            print(f"🔷 You discover a Forest Relic! ({player['relics']}/3)")
        else:
            player["potions"] += 1
            print("You find a spare potion near the ancient shrine.")

    player["forest_visits"] += 1
    return True


def visit_village(player):
    """Let the player buy supplies or receive a helpful hint."""
    print("\n🏘️ You arrive at Lantern Village.")
    print("A shopkeeper waves from a little wooden stall.")
    print("1. Buy a potion (5 rupees)")
    print("2. Improve your sword (8 rupees, +1 damage)")
    print("3. Hear a hint")
    print("4. Leave village")
    choice = input("What would you like to do? ").strip()

    if choice == "1":
        if player["rupees"] >= 5:
            player["rupees"] -= 5
            player["potions"] += 1
            print("You buy a potion. 🍶")
        else:
            print("You don't have enough rupees.")
    elif choice == "2":
        if player["rupees"] >= 8:
            player["rupees"] -= 8
            player["sword_power"] += 1
            print("Your sword is upgraded! Your attacks are stronger. ⚔️")
        else:
            print("You need 8 rupees for the upgrade.")
    elif choice == "3":
        print('"Search the forest for relics, then cross the bridge to face the dragon."')
        print('"A stronger sword and a few potions will help you survive."')
    elif choice == "4":
        print("You leave the village and return to the trail.")
    else:
        print("The shopkeeper looks confused. You head back to the trail.")


def enter_cave(player):
    """Explore the cave for the final relic and fight a cave monster."""
    print("\n🕯️ You step into the Crystal Cave. Blue crystals light the walls.")
    if not player["cave_cleared"]:
        won = fight_enemy(player, "Cave Troll", 6, 2)
        if not won:
            return False
        player["cave_cleared"] = True
        if player["relics"] < 3:
            player["relics"] += 1
            print(f"🔷 The troll guarded a Crystal Relic! ({player['relics']}/3)")
        else:
            player["potions"] += 1
            print("Behind the troll, you find a healing potion.")
    else:
        print("The cave is quiet now. You have already explored it.")
    return True


def face_boss(player):
    """Start the final boss battle when the player is ready."""
    print("\n🌋 You cross the old bridge and enter the Dragon's Ruins.")
    if player["relics"] < 3:
        print("A magical barrier blocks the entrance!")
        print(f"You need 3 relics, but you only have {player['relics']}. Explore the forest and cave first.")
        return True

    print("The three relics glow. The barrier disappears!")
    print("A huge shadow rises from the ruins...")
    pause(0.8)
    won = fight_enemy(player, "SHADOW DRAGON", 12, 3, boss=True)
    if not won:
        return False

    print("\n🏆 The Shadow Dragon has been defeated!")
    print("Light returns to the kingdom, and the villagers celebrate your victory.")
    print(f"Congratulations, {player['name']}! You are the Hero of the Realm!")
    return True


def main():
    """Run the whole adventure from beginning to end."""
    print("=" * 42)
    print("      THE LEGEND OF THE THREE RELICS")
    print("=" * 42)
    name = input("What is your hero's name? ").strip()
    if not name:
        name = "Link"

    # The main character is represented by a dictionary.
    player = {
        "name": name,
        "hp": 8,
        "max_hp": 8,
        "potions": 2,
        "rupees": 6,
        "relics": 0,
        "sword_power": 2,
        "location": "Village Trail",
        "forest_visits": 0,
        "cave_cleared": False
    }

    print(f"\nWelcome, {player['name']}!")
    print("The Shadow Dragon has stolen the kingdom's light.")
    print("Find 3 relics, prepare your gear, and defeat the dragon!")
    print("Tip: You can visit the village between adventures to buy supplies.")
    pause()

    game_over = False
    while not game_over and player["hp"] > 0:
        show_status(player)
        print("\nWhere would you like to go?")
        print("1. Whispering Forest (search for relics and treasure)")
        print("2. Lantern Village (buy supplies or upgrade your sword)")
        print("3. Crystal Cave (fight a monster and find a relic)")
        print("4. Dragon's Ruins (final boss)")
        print("5. Quit game")
        choice = input("Choose 1-5: ").strip()

        if choice == "1":
            player["location"] = "Whispering Forest"
            game_over = not explore_forest(player)
        elif choice == "2":
            player["location"] = "Lantern Village"
            visit_village(player)
        elif choice == "3":
            player["location"] = "Crystal Cave"
            game_over = not enter_cave(player)
        elif choice == "4":
            player["location"] = "Dragon's Ruins"
            game_over = not face_boss(player)
            if not game_over and player["hp"] > 0 and player["relics"] >= 3:
                # The boss victory ends the game.
                game_over = True
                print("\nThanks for playing!")
        elif choice == "5":
            print("You leave the adventure for another day. Thanks for playing!")
            game_over = True
        else:
            print("Please enter a number from 1 to 5.")

    if player["hp"] <= 0:
        print("\nGAME OVER — try again and save the kingdom!")
    elif player["relics"] >= 3 and player["hp"] > 0:
        print(f"Final stats: {player['hp']}/{player['max_hp']} hearts, "
              f"{player['rupees']} rupees, sword power {player['sword_power']}.")


if __name__ == "__main__":
    main()
